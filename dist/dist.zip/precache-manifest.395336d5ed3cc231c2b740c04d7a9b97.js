self.__precacheManifest = [
  {
    "revision": "f12e19dff9f115e7c462",
    "url": "/css/app.783be92a.css"
  },
  {
    "revision": "f12e19dff9f115e7c462",
    "url": "/js/app.d534b539.js"
  },
  {
    "revision": "cec71b5a5cd660021af3",
    "url": "/css/buefy.80115c7f.css"
  },
  {
    "revision": "cec71b5a5cd660021af3",
    "url": "/js/buefy.e6a0535e.js"
  },
  {
    "revision": "b05a654df1a300220810",
    "url": "/css/chunk-012f73a6.8b5fefc0.css"
  },
  {
    "revision": "b05a654df1a300220810",
    "url": "/js/chunk-012f73a6.765366ea.js"
  },
  {
    "revision": "c9d31be5b3830150fb0e",
    "url": "/css/chunk-0770a96b.f52010a3.css"
  },
  {
    "revision": "c9d31be5b3830150fb0e",
    "url": "/js/chunk-0770a96b.1aeeff0b.js"
  },
  {
    "revision": "7f88209a55d1af046677",
    "url": "/css/chunk-1d3ed695.0e433876.css"
  },
  {
    "revision": "7f88209a55d1af046677",
    "url": "/js/chunk-1d3ed695.e400d5f2.js"
  },
  {
    "revision": "78d8388dc56f2817af3a",
    "url": "/js/chunk-2d0c115c.d9613233.js"
  },
  {
    "revision": "d04c380659d82b18286c",
    "url": "/js/chunk-2d0c49f5.9aeb58bd.js"
  },
  {
    "revision": "6bfb128347bb0704cf7e",
    "url": "/js/chunk-2d0e8e0f.8491986f.js"
  },
  {
    "revision": "1201de4e74ccd7dce01c",
    "url": "/css/chunk-37622720.c6bcad0d.css"
  },
  {
    "revision": "1201de4e74ccd7dce01c",
    "url": "/js/chunk-37622720.0951368e.js"
  },
  {
    "revision": "b9e11a948820e7884dce",
    "url": "/css/chunk-445b8669.0e433876.css"
  },
  {
    "revision": "b9e11a948820e7884dce",
    "url": "/js/chunk-445b8669.7b8c5dce.js"
  },
  {
    "revision": "55cd254205befdd01f2d",
    "url": "/css/chunk-448247c9.0e433876.css"
  },
  {
    "revision": "55cd254205befdd01f2d",
    "url": "/js/chunk-448247c9.e4b130c2.js"
  },
  {
    "revision": "528eca636c2b5d90222d",
    "url": "/css/chunk-4c77c558.fb1cb92b.css"
  },
  {
    "revision": "528eca636c2b5d90222d",
    "url": "/js/chunk-4c77c558.965df4e5.js"
  },
  {
    "revision": "8b44946a5aa63c3ab832",
    "url": "/css/chunk-65b6843b.c6bcad0d.css"
  },
  {
    "revision": "8b44946a5aa63c3ab832",
    "url": "/js/chunk-65b6843b.80592228.js"
  },
  {
    "revision": "b3a5401f9cdac69ec5c3",
    "url": "/css/chunk-6c52885c.934f2447.css"
  },
  {
    "revision": "b3a5401f9cdac69ec5c3",
    "url": "/js/chunk-6c52885c.9322c6da.js"
  },
  {
    "revision": "de6034d2730333f6b8aa",
    "url": "/css/chunk-713294d9.0e433876.css"
  },
  {
    "revision": "de6034d2730333f6b8aa",
    "url": "/js/chunk-713294d9.57179929.js"
  },
  {
    "revision": "a379affb5249fc949d1a",
    "url": "/css/chunk-72bb9abb.e84cd741.css"
  },
  {
    "revision": "a379affb5249fc949d1a",
    "url": "/js/chunk-72bb9abb.4ac511d7.js"
  },
  {
    "revision": "9dcafc0b382a69e8416c",
    "url": "/css/chunk-745a6914.0e433876.css"
  },
  {
    "revision": "9dcafc0b382a69e8416c",
    "url": "/js/chunk-745a6914.f37e9755.js"
  },
  {
    "revision": "91a6d226d9d854e4736c",
    "url": "/css/chunk-773e0a6a.ca8b8fba.css"
  },
  {
    "revision": "91a6d226d9d854e4736c",
    "url": "/js/chunk-773e0a6a.1dd8b223.js"
  },
  {
    "revision": "442646bc9f049f10967e",
    "url": "/css/chunk-89136cee.0e433876.css"
  },
  {
    "revision": "442646bc9f049f10967e",
    "url": "/js/chunk-89136cee.53b7d053.js"
  },
  {
    "revision": "5e8f9543f7fec21663a0",
    "url": "/css/chunk-b3581b2a.934f2447.css"
  },
  {
    "revision": "5e8f9543f7fec21663a0",
    "url": "/js/chunk-b3581b2a.b808b168.js"
  },
  {
    "revision": "f6945eddfda9b79b088c",
    "url": "/css/chunk-f7febe62.934f2447.css"
  },
  {
    "revision": "f6945eddfda9b79b088c",
    "url": "/js/chunk-f7febe62.c03c5350.js"
  },
  {
    "revision": "928f0638c5bc9825eb0f",
    "url": "/js/runtime.90dac03d.js"
  },
  {
    "revision": "f879cff7a5268d683fae",
    "url": "/js/vendor.8095a74d.js"
  },
  {
    "revision": "be18ba5094a13ad281dd04e09717d121",
    "url": "/index.html"
  },
  {
    "revision": "b0e68da45daef7326e6e2360981fbb43",
    "url": "/assets/img/beer.png"
  },
  {
    "revision": "d093d78b8ab5c146bf07d9188d89a0e0",
    "url": "/assets/img/collection.jpeg"
  },
  {
    "revision": "aaeeb91f9c4922c063d66401669c1d81",
    "url": "/assets/img/choose.png"
  },
  {
    "revision": "41da89e2aafe0b74c705c8019b9249f3",
    "url": "/assets/img/collection1.jpeg"
  },
  {
    "revision": "6e9428fad99d2f094f985d01753125ac",
    "url": "/assets/img/cargo-truck.png"
  },
  {
    "revision": "658331b16334e6e9d553ce7ab16d487c",
    "url": "/assets/img/connections.jpeg"
  },
  {
    "revision": "e851837409473e9833b48a7a41816ea5",
    "url": "/assets/img/collection2.jpeg"
  },
  {
    "revision": "4dfa7cbd9f23293a39e4c270728c4b1b",
    "url": "/assets/img/like.png"
  },
  {
    "revision": "55fa48aae63dbbdc52d80af03309c656",
    "url": "/assets/img/cutlery.png"
  },
  {
    "revision": "22c090314be3157f25e183b2c465a4ae",
    "url": "/assets/img/logo-removebg-preview.png"
  },
  {
    "revision": "02a957a7b9d272fc9aa5de5c1ff6ed07",
    "url": "/assets/img/map.png"
  },
  {
    "revision": "c2ae524227ef9d191a3bb0b25cd46ff0",
    "url": "/assets/img/logo.jpeg"
  },
  {
    "revision": "f5a9aca12f91c12f22c0ad3258e685d8",
    "url": "/assets/img/order.png"
  },
  {
    "revision": "c740d55d51adeb6d199f79826c558ea2",
    "url": "/assets/img/test-bg.jpg"
  },
  {
    "revision": "59c17cb4a304d7e361d4538e307a9bee",
    "url": "/assets/img/restaurant-listing.png"
  },
  {
    "revision": "8b804a4f0f106369f8bf4c07bc8469cd",
    "url": "/assets/img/2664646.jpg"
  },
  {
    "revision": "c11c5c9d3fb8e07da04c2ad551ebac34",
    "url": "/assets/img/background-home.jpg"
  }
];